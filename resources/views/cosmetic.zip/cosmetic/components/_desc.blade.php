
<style>
    @media (max-width: 767px)  {
        #footer ul li span{
            font-size: 12px;
        }
        .activityImage{
            height: 80px;
        }
        }
</style>

<footer>
    <div class="footer-top">
        <div style="text-align: center;">
            <h3 class="title" style="color: black;font-size: 30px;font-family: persofont;font-weight: bolder;">
                BeautyCom Cosmetic
            </h3>

            <p style="color: white;font-size: 17px;">
                Le soin de la beauté idéale se resume dans ces rubriques 
            </p>
            <p style="font-size: 18px;color: white;">
                Vente des articles de beauté
            </p>
        </div>

        <div class="container">
            <div class="row">

                <div id="newslatter" class="col-sm-4">
                    <div class="block_newsletter">
                        <h3 class="h3 hidden-sm-down">
                             <span class="title" style="color: black;">
                                <span>
                                    <img class="activityImage" src="{{  asset("cosmetic/image/Woman_Hair_100px.png")  }}" alt="">
                                </span>
                                <br>
                                Mèches de cheveux
                            </span>
                            <span class="desc" style="color: white;">
                                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Doloremque dolore praesentium totam odio harum sapiente quasi veniam fuga sequi eum.
                            </span>
                        </h3>
                    </div>
                </div>

                <div id="newslatter" class="col-sm-4">
                    <div class="block_newsletter">
                        <h3 class="h3 hidden-sm-down">
                             <span class="title" style="color: black;">
                                <span>
                                    <img class="activityImage" src="{{  asset("cosmetic/image/Barbershop_100px.png")  }}" alt="">
                                </span>
                                <br>
                                Make-up 
                            </span>
                            <span class="desc" style="color: white;">
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum excepturi voluptate impedit eum. Rerum mollitia expedita in, inventore iure soluta?
                            </span>
                        </h3>
                    </div>
                </div>

                <div id="newslatter" class="col-sm-4">
                    <div class="block_newsletter">
                        <h3 class="h3 hidden-sm-down">
                             <span class="title" style="color: black;">
                                <span>
                                    <img class="activityImage" src="{{  asset("cosmetic/image/Tube_100px.png")  }}" alt="">
                                </span>
                                <br>
                                Laits de beauté
                            </span>
                            <span class="desc" style="color: white;">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. A voluptates repellendus vel sit modi esse architecto placeat magnam laboriosam repudiandae.
                            </span>
                        </h3>
                    </div>
                </div>

  </div>


    </div>
    </div>
</div>

</footer>
