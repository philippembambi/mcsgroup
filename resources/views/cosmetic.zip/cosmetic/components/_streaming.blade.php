<style>
    .about-video .play-icon {
        background: rgb(41, 62, 2);
    }
    #streaming{
        margin-top: -5%;
    }
    .small{
        height: 220px;
    }
    @media (max-width: 767px)
    {
        .videoimg{
            height: 220px;    
        }
    }
</style>
<!-- SECTION -->

                <div class="section" id="streaming">	
                    	
                    <!-- Products tab & slick -->
                    <div class="col-md-12">
                        
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4 col-md-offset-1">
                                                            <!-- Cart -->
                                <div class="dropdown">
                                    <a class="about-video dropdown-toggle" 
                                        data-toggle="dropdown" aria-expanded="true" 
                                        href="#">
                                        <img    src="{{  asset("cosmetic/image/makeup-brushes-g9fc5d7189_1920.jpg")  }}" 
                                                class="videoimg" alt="">
                                        <i class="play-icon fa fa-play"></i>
                                    </a>
                                </div>
                                <br>
                            </div>
        
                            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-4 col-md-offset-1">
                               
                                <div class="dropdown">
                                                                
                                <a class="about-video dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#">
                                    <img src="{{  asset("cosmetic/image/applying-g04e2152fb_1920.jpg")  }}" class="videoimg small" alt="">
                                        <i class="play-icon fa fa-play"></i>
                                </a>                                                                                          
                                </div>
                                <br>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-4 col-md-offset-1">
                               
                                <div class="dropdown">
                                                                
                                <a class="about-video dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="#">
                                    <img src="{{  asset("cosmetic/image/images38.jpg")  }}" class="videoimg small" alt="">
                                        <i class="play-icon fa fa-play"></i>
                                </a>                                                                                          
                                </div>
                                <br>
                            </div>



                            </div>
                            <!-- Products tab & slick -->
                </div>
                </div>
                <!-- /SECTION -->
        